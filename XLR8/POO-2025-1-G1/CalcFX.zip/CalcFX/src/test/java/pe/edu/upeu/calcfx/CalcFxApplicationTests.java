package pe.edu.upeu.calcfx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalcFxApplicationTests {

	@Test
	void contextLoads() {
	}

}
